void print_settings(param *lisod_param);
void print_request(Requests *requests);
void print_request_analyzed(Request_analyzed *request_analyzed);
void print_response_headers(Response_headers *response_headers);
void print_resp_ptr(int connfd, pools *p);
void print_resp_item(int connfd, pools *p);
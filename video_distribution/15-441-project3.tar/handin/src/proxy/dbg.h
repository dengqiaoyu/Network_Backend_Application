void print_argv(param *proxy_param);
void print_req(Requests *req);
void print_s2c_list(s2c_data_list_t *s2c_list);
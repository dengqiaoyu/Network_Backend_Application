int init_log(char *log_file, int argc, char **argv);
void close_log(FILE *logfp);